import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { AlertController, MenuController, Platform } from '@ionic/angular';
import { App } from 'src/AppConstant';

@Injectable({
  providedIn: 'root'
})
export class DataService {
  theme = 'light'
  selectedPostId = '00';
  selectedPost: any = [];
  allPost = [];
  featurePost: any[] = [];
  relatedArticles: any = [];
  selectedCategory = '';
  BaseUrl = '';
  language: string = '';
  isLoading: boolean = false;
  topNav: any[] = [];
  restart: boolean = false;
  postData: any = [] = [];
  page = 1;
  notification: any = [];
  constructor(
    public http: HttpClient,
    public alertController: AlertController,
    public menuCtr: MenuController,
    private platform: Platform,
    public domSanitizer: DomSanitizer,
    // private app: appini
  ) {
    this.setLanguage();
    this.getAllNavCategory();
    this.getAllPost();
    this.addNotifyLocal(null)
  }

  updateDevicetoken(token: string) {

    const headers = {
      'Access-Control-Allow-Origin': '*',
      'Content-Type': 'application/json'
    };
    try {
      this.http.get(this.BaseUrl + App.TokenUploadApi + token + "", { headers })
        .subscribe((res: any) => {
          console.log(res);
        });
    } catch (error) {
      console.log(error);
    }
  }

  ionSlideTouchEnd() {
  }

  async getAllNavCategory() {
    this.appReload();
    this.topNav = []
    try {
      this.isLoading = true
      this.http.get(this.BaseUrl + App.PostFix + App.NavCategoryPerPage)
        .subscribe((res: any) => {
          let rest = res
          // console.log('Category res >>>>>>>', rest);
          for (let i = 0; i < rest.length; i++) {
            if (rest[i].count > 0) {
              this.topNav.push(rest[i]);
              // console.log(this.topNav[i].name)
            }
          }
          this.topNav = this.topNav.sort(function (countFirst, countLast) { return countLast.count - countFirst.count })
          this.isLoading = false;
          // console.log('Category res >>>>>>>', this.topNav);
        });
    } catch (error) {
      console.log(error);
      alert('error');
      this.isLoading = false
    }
  }

  async getAllPost() {
    try {
      this.isLoading = true
      this.http.get(this.BaseUrl + App.PostFix + App.PostPage + this.page + App.Embd)
        .subscribe((res: any) => {
          this.postData = [] = []
          const featurepost = []
          for (let i = 0; i < res.length; i++) {
            if (res[i].content.rendered) {
              if (i < 4) {
                featurepost.push(res[i])
              } else {
                this.postData.push(res[i])
              }
            }
            this.featurePost = featurepost;
          }
          if(this.selectedPostId != '00'){
            this.filterPost(this.selectedPostId);
          }
          this.isLoading = false;
          console.log(this.postData)
          return this.postData
        });
    } catch (error) {
      console.log(error);
      alert('error');
      this.isLoading = false;
      // return null
    }
  }

  async getNextPost() {
    this.page = this.page + 1;
    console.log(this.page);
    var updatedData: any[] = []
    try {
      this.isLoading = true
      this.http.get(this.BaseUrl + App.PostFix + App.PostPage + this.page + App.Embd)
        .subscribe((resp: any) => {
          updatedData = resp;
          resp.forEach((element: any) => {
            this.postData.push(element)
          });
        });
      this.isLoading = false
      console.log(this.postData)
    } catch (error) {
      console.log(error);
      alert('error');
      this.isLoading = false
    }
  }

  setLanguage() {
    let lang = localStorage.getItem('language');
    console.log(lang)
    if (lang == '' || lang == 'english' || !lang) {
      this.language = 'english';
      localStorage.setItem('language', this.language);
      this.BaseUrl = App.BaseUrl;
      return
    } if (lang == 'hindi') {
      this.language = 'hindi';
      localStorage.setItem('language', this.language);
      this.BaseUrl = App.BaseUrl2;
    }
    console.log('this is lang is hare >>>>>> ', lang);
  }

  async getRelatedArticle(catId:any) {
    let id = catId.toString();
    try {
      this.isLoading = true
      this.http.get(this.BaseUrl + App.PostFix + App.Posts+ App.PostCategoryId + id + App.Embd+ App.PerPage +20)
        .subscribe((res: any, ) => {
          console.log(res)
          this.relatedArticles = [] = []
          const articles = []
          for (let i = 1; i < res.length; i++) {
            if (res[i].content.rendered) {
                articles.push(res[i])
            }
            this.relatedArticles = articles;
          }
          this.isLoading = false;
          console.log(this.relatedArticles)
          return this.relatedArticles
        }, (error)=> {
          this.isLoading = false;
          console.log(error)
        });
    } catch (error) {
      console.log(error);
      alert('error');
      this.isLoading = false;
      // return null
    }
  }

  async LangAlert() {
    let lang = '';
    const header = 'Change language?';
    let subHeader = '';
    if (this.language == 'hindi') {
      subHeader = 'English Language';
      lang = 'english'
    } if (this.language == 'english') {
      subHeader = 'हिन्दी भाषा'
      lang = 'hindi'
    }
    console.log(lang)

    const alert = await this.alertController.create({
      mode: "ios",
      header: header,
      subHeader: subHeader,
      backdropDismiss: true,
      buttons: [
        {
          text: 'Cancel',
          role: 'cancel',
          handler: () => {
            // this.menuCtr.close()
          },
        },
        {
          text: 'OK',
          role: 'confirm',
          handler: () => {
            console.log(lang)
            localStorage.setItem('language', lang);
            this.language = lang;
            if (this.language == 'hindi') {
              this.BaseUrl = App.BaseUrl2;
              console.log(this.BaseUrl);
              this.getAllNavCategory();
              this.getAllPost()
            }
            if (this.language == 'english') {

              this.BaseUrl = App.BaseUrl;
              console.log(this.BaseUrl)
              this.getAllNavCategory();
              this.getAllPost()
            }
            // this.menuCtr.close()
          },
        },
      ],

    });

    await alert.present();
  }

  getPostById(id: string) {
    try {
      this.isLoading = true
      this.http.get(this.BaseUrl + App.PostFix + App.Posts + id + '?_embed')
        .subscribe(async (res: any) => {
          this.selectedPost = await res;
          this.selectedPost.content.rendered = this.domSanitizer.bypassSecurityTrustHtml(this.selectedPost.content.rendered);
          console.log('selected post res >>>>>>>', this.selectedPost);
          this.isLoading = false;
        });
      return this.selectedPost
    } catch (error) {
      console.log(error);
      this.isLoading = false
      return null
    }
  }

  initializeApp() {
    this.platform.ready().then(() => {
    });
  }

  appReload() {
    let theme = localStorage.getItem('theme');
    if(theme){
      this.theme = theme;
      console.log(this.theme)
    }
    else{
      localStorage.setItem('theme', this.theme)
    }
    this.restart == true
    setTimeout(() => {
      this.restart == false
    }, 3000);
  }


  addNotifyLocal(data: any) {
    //from hare to 
    // const obj ={
    //   action: "tabs/tab1/post-details",
    //   body: "testing",
    //   id: crypto.randomUUID(),
    //   image: "https://foo.bar/pizza-monster.png",
    //   title:"send by postman opera",
    //   wasTapped: false
    // }
    // let datas = obj;
    //hare ... comment this before build 
    if(data){
      let notifi = localStorage.getItem('notifications');
      if(notifi){
        this.notification = JSON.parse(notifi);
        this.notification.push({data});
        localStorage.setItem('notifications',JSON.stringify(this.notification));
        return
      }    
      else {
        this.notification = [];
        this.notification.push({data});
        localStorage.setItem('notifications',JSON.stringify(this.notification));
      }
    }
    else{
      let notifi = localStorage.getItem('notifications');
      if(notifi){
        this.notification = JSON.parse(notifi);
      }
       
    }
    
  }

  filterPost(id: any) {
    this.selectedPost = this.allPost.filter((item: any) => {
      if(item.id == id){
        console.log(item)
        return item
      }
    })
  }

  

}
