import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-save-posts',
  templateUrl: './save-posts.page.html',
  styleUrls: ['./save-posts.page.scss'],
})
export class SavePostsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
