import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DataService } from 'src/app/services/data.service';

@Component({
  selector: 'app-notification',
  templateUrl: './notification.page.html',
  styleUrls: ['./notification.page.scss'],
})
export class NotificationPage implements OnInit {

  constructor(
    public dataService: DataService,
    private router: Router
  ) { }

  ngOnInit() {
  }

  gotoDetailsPage(val: any) {
    console.log(val)
    this.dataService.getPostById(val.data.id)
    this.router.navigate(['tabs/tab1/post-details']);
  }

  goBack(){
    this.router.navigate(['tabs'])
  }
}
