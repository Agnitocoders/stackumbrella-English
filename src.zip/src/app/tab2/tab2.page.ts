import { Component } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { App } from 'src/AppConstant';
import { DataService } from '../services/data.service';
// import { InAppBrowser, InAppBrowserOptions } from '@awesome-cordova-plugins/in-app-browser/ngx';

@Component({
  selector: 'app-tab2',
  templateUrl: 'tab2.page.html',
  styleUrls: ['tab2.page.scss']
})
export class Tab2Page {
  url = 'https://stackumbrella.com/web-stories';
  render: boolean = false;
  constructor(
    public dataService: DataService,
    private sanitizer: DomSanitizer
  ) { }

  ionViewWillEnter() {
    this.render == true;
    // this.url = this.sanitizer.bypassSecurityTrustUrl(this.dataService.BaseUrl + App.WebStory)
  }



}
